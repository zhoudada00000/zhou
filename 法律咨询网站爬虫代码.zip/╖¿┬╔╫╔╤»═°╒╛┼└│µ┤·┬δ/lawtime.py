#                    _ooOoo_
#                   o8888888o
#                   88" . "88
#                   (| -_- |)
#                   O\  =  /O
#                ____/`---'\____
#              .'  \\|     |//  `.
#             /  \\|||  :  |||//  \
#            /  _||||| -:- |||||-  \
#            |   | \\\  -  /// |   |
#            | \_|  ''\---/''  |   |
#            \  .-\__  `-`  ___/-. /
#          ___`. .'  /--.--\  `. . __
#       ."" '<  `.___\_<|>_/___.'  >'"".
#      | | :  `- \`.;`\ _ /`;.`/ - ` : | |
#      \  \ `-.   \_ __\ /__ _/   .-` /  /
# ======`-.____`-.___\_____/___.-`____.-'======
#                    `=---='
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#             佛祖保佑       永无BUG
import re

import requests
from lxml import etree
import time
import random
from bs4 import BeautifulSoup
import csv


def down(url, params=None):
    '''
    根据给定的url下载指定的页面
    :param url:
    :param params:
    :return:
    '''
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'
        # 'User-Agent': 'Dalvik/2.1.0 (Linux; U; Androidd
    }
    '''
    断线续爬的尝试机制
    
    '''
    nums = 1
    while nums <= 3:

        try:
            f = open("IP.txt", "r")
            file = f.readlines()

            # 遍历并分别存入列表，方便随机选取IP
            item = []
            for proxies in file:
                proxies = eval(proxies.replace('\n', ''))  # 以换行符分割，转换为dict对象
                item.append(proxies)

            proxies = random.choice(item)
            response = requests.get(url, params=params, headers=headers, proxies=proxies)
            # print(response.status_code)
            if response.status_code == 200:
                return response
            else:

                nums += 1
                time.sleep(random.random())
                # time.sleep(random.randint(2, 5))

        except Exception as e:
            # time.sleep(random.randint(2, 5))
            print(e)
            nums += 1
            time.sleep(random.random())

    return None


n = 99500
while True:
    print(n)
    url = 'https://www.lawtime.cn/ask/question_{}.html'.format(n)
    try:
        resp = down(url)
        tree = etree.HTML(resp.text)
        html = resp.text
        soup = BeautifulSoup(html, 'html.parser')
        time.sleep(random.random())
        question = soup.select('h1')
        question_des = soup.select('div.desc-content')
        print(question[0].text)
        answers = soup.select('div.ask-content')
        print(len(answers))
        if len(answers) == 0:
            pass
            n += 1
        else:

            for answer in answers[0:-1]:
                b = 'answer'
                fp = open('lawtime.csv', mode='a+', newline='', encoding='GBK', errors='ignore')
                writer = csv.writer(fp)

                writer.writerow([question[0].text + question_des[0].text, answer.text])
            print('写入成功')
            n += 1
    except:
        time.sleep(random.randint(2, 5))
        n += 1
