import requests
from lxml import etree
import time
import random
from bs4 import BeautifulSoup
import csv
import importlib
import sys

importlib.reload(sys)


def down(url, params=None):
    '''
    根据给定的url下载指定的页面
    :param url:
    :param params:
    :return:
    '''

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'
        # 'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; MI 5s Build/V417IR)',
    }
    '''
    断线续爬的尝试机制 
    '''

    nums = 1
    while nums <= 5:

        try:
            response = requests.get(url, params=params, headers=headers)
            if response.status_code == 200:
                return response
            else:
                nums += 1
                time.sleep(random.random())
                time.sleep(random.randint(20, 50))

        except Exception as e:
            time.sleep(random.randint(20, 50))
            print(e)
            nums += 1
            time.sleep(random.random())

    return None


pn = 102180
# 2023.5.26 已结束
while True:
    print(pn)
    try:

        resp = down('https://www.haolvshi.com.cn/ask/{}.html'.format(pn))
        pn += 1

        tree = etree.HTML(resp.text)
        html = resp.text
        soup = BeautifulSoup(html, 'html.parser')
        time.sleep(random.random())
        try:

            question = tree.xpath('//*[@class="l3"]//text()')
        except:

            question = []
        question1 = ''
        for i in range(len(question) - 1):
            question1 += question[i]

        question_sup = soup.select('.clearfix>.truncated')
        print('Question:', question1.replace(' ', ''))
        answers = soup.select('.replyContainer .replyList')

        print(len(answers))

        for answer in answers:
            answer1 = answer.select('.truncated')
            if answer1 == '':
                pass
            print(answer1[0].text.replace('自动转换：', ''))

            try:
                fp = open('haolvshi_2.csv', mode='a+', newline='', encoding='GBK', errors='ignore')
                writer = csv.writer(fp)

                writer.writerow(
                    [question1.replace(' ', '').replace('展开', '').replace('收起', ''),
                     answer1[0].text.replace('自动转换：', '')])

            except:

                pass
    except:
        time.sleep(random.randint(10,50))
        pn += 1
