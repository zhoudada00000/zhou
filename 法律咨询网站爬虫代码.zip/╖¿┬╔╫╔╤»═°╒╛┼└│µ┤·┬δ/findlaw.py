import multiprocessing
import os

import pytesseract
import requests
from PIL import Image
from lxml import etree
import time
import random
from bs4 import BeautifulSoup

import csv
from selenium import webdriver
from selenium.webdriver.common.by import By
import importlib
import sys

importlib.reload(sys)


def yzm():
    from selenium.webdriver import Chrome
    from selenium.webdriver.chrome.options import Options

    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument(
        'user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36')

    driver = Chrome('./chromedriver', options=chrome_options)
    driver.get('http://ipfilter.lsurl.cn/ipfilter/?continue=aHR0cDovL3d3dy5maW5kbGF3LmNuL3dlbmRhL3FfNzE5NS5odG1s')

    yzm = driver.find_elements(By.ID, 'vimg')[0].get_attribute('src')

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'
        # 'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; MI 5s Build/V417IR)',

    }
    # 发送请求图片
    res = requests.get(url=yzm, headers=headers)

    # 设置一个变量，该变量为指定保存的路径,windows系统下的 D盘，test目录
    dir_name = 'D:\\yzmimages'

    # 判断 指定目录，如果不存在该目录，则创建该目录
    if not os.path.exists(dir_name):
        os.mkdir(dir_name)
    # 指定路径（拼接上图片名及后缀
    path = dir_name + '\\verification.jpg'

    # 把获取的二进制写入图片文件  （注意：这里直接写入在Pycharm中可能只显示创建的目录而不显示文件，在文件夹中打开就可）
    with open(path, mode='wb') as f:
        f.write(res.content)
    print(path)
    # 将图片文件的保存路径返回
    image = Image.open(path)
    text = pytesseract.image_to_string(image, lang='eng+osd')
    print(text)
    input = driver.find_elements(By.ID, 'vgcode')[0]
    input.send_keys(text)
    time.sleep(random.random())
    button = driver.find_elements(By.ID, 'resubimt')[0]
    button.click()
    time.sleep(10)
    driver.quit()


def down(url, params=None):
    '''
    根据给定的url下载指定的页面
    :param url:
    :param params:
    :return:
    '''

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'
        # 'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; MI 5s Build/V417IR)',

    }
    '''
    断线续爬的尝试机制
    '''
    nums = 1
    while nums <= 3:

        try:
            # 打开文件，换行读取
            f = open("IP.txt", "r")
            file = f.readlines()

            # 遍历并分别存入列表，方便随机选取IP
            item = []
            for proxies in file:
                proxies = eval(proxies.replace('\n', ''))  # 以换行符分割，转换为dict对象
                item.append(proxies)

            proxies = random.choice(item)  # 随机选取一个IP
            response = requests.get(url, params=params, headers=headers, proxies=proxies)
            tree = etree.HTML(response.text)

            time.sleep(random.random())
            if len(tree.xpath('//*[@class="none-mes"]')) != 0:
                print('问题已被删除')
                nums += 3
                pass
            if len(tree.xpath('//*[@class="yzm-pic"]')) != 0:
                print('请稍等')
                yzm()

                nums += 1
                time.sleep(random.randint(2, 5))
                continue
            if response.status_code == 200:
                return response
            else:
                nums += 1
                time.sleep(random.randint(2, 5))
                time.sleep(random.random())

        except Exception as e:
            time.sleep(random.randint(2, 5))
            print(e)
            nums += 1
            time.sleep(random.random())

    return None


start_urls = [
    'https://www.findlaw.cn/wenda/q_{}.html'.format(
        i) for i in range(403123, 3500000)]


def page(url):
    try:

        time.sleep(random.random())
        print(url)

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.35 Safari/537.36', }
        resp = down(url)
        tree = etree.HTML(resp.text)

        html = resp.text
        soup = BeautifulSoup(html, 'html.parser')
        time.sleep(random.random())
        question = tree.xpath('//*[@class="wl_box"]//text()')
        question1 = ''

        for i in range(len(question) - 1):
            question1 += question[i]
        print('Question:', question1.replace(' ', ''))
        answers = soup.select('ul.resolve-list>li>div>div.resolve-txt')

        print(len(answers))

        a = 0
        for answer in answers[0:-1]:

            try:
                fp = open('找法网_2.csv', mode='a+', newline='', encoding='GBK')
                writer = csv.writer(fp)

                writer.writerow([question1.replace(' ', ''), answer.text])

            except:

                pass

    except:
        time.sleep(random.random())
        fp = open('找法网_url.csv', mode='a+', newline='', encoding='GBK')
        writer = csv.writer(fp)

        writer.writerow([url])
        pass


if __name__ == '__main__':
    q = multiprocessing.Pool(10)

    for link in start_urls:
        q.apply_async(page, args=(link,))

    q.close()
    q.join()
