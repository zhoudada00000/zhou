#                    _ooOoo_
#                   o8888888o
#                   88" . "88
#                   (| -_- |)
#                   O\  =  /O
#                ____/`---'\____
#              .'  \\|     |//  `.
#             /  \\|||  :  |||//  \
#            /  _||||| -:- |||||-  \
#            |   | \\\  -  /// |   |
#            | \_|  ''\---/''  |   |
#            \  .-\__  `-`  ___/-. /
#          ___`. .'  /--.--\  `. . __
#       ."" '<  `.___\_<|>_/___.'  >'"".
#      | | :  `- \`.;`\ _ /`;.`/ - ` : | |
#      \  \ `-.   \_ __\ /__ _/   .-` /  /
# ======`-.____`-.___\_____/___.-`____.-'======
#                    `=---='
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#             佛祖保佑       永无BUG
#
# coding:utf-8 jia
import csv
import requests
from bs4 import BeautifulSoup
from lxml import etree
import time
import random


def down(url, params=None):
    '''
    根据给定的url下载指定的页面
    :param url:
    :param params:
    :return:
    '''
    headers = {
        # 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; MI 5s Build/V417IR)',
    }
    '''
    断线续爬的尝试机制
    
    '''
    nums = 1
    while nums <= 3:
        try:
            response = requests.get(url, params=params, headers=headers)
            if response.status_code == 200:
                return response
            else:
                nums += 1
                time.sleep(random.random())
        except Exception as e:
            print(e)
            nums += 1
            time.sleep(random.random())

    return None


pn = 197353
while True:

    print('pn:', pn)
    try:
        url = 'https://lvlin.baidu.com/pc/q-{}c49adbf5e24bc7e30640427aca1deb34.html'.format(pn)
        resp = down(url)
        tree = etree.HTML(resp.text)
        html = resp.text
        soup = BeautifulSoup(html, 'html.parser')
        time.sleep(random.random())
        question = tree.xpath('//*[@class="question-title"]//text()')
        # answers = tree.xpath('//*[@class="question-content-text"]//text()')
        answers = soup.select('div.question-content-text')
        # print(len(answers))
        if len(answers[0].text) == 0:
            pn += 1
            pass
        else:
            print('Question:', question[0])
            print('answers:', answers[0].text)

            fp = open('lvlin.csv', mode='a+', newline='', encoding='gbk', errors='ignore')
            writer = csv.writer(fp)

            writer.writerow([question[0],
                             answers[0].text.replace('\xa0', '').replace('\u2002', '').replace('\u2003', '').replace(
                                 '\u2716', '').replace('\ufe0f', '').replace('\u200d', '').replace("r'\'(.*?)",
                                                                                                   '').replace(
                                 '\u2022', '').replace('\ue771', '')])

            time.sleep(random.random())

            pn += 1
    except:
        time.sleep(random.randint(10, 20))
        pn += 1
